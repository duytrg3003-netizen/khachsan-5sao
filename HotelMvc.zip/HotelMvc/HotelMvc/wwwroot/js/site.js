document.querySelectorAll("[data-room-photo]").forEach(button => {
    button.addEventListener("click", () => {
        document.getElementById("room-photo").src = button.dataset.roomPhoto;
        document.querySelectorAll("[data-room-photo]").forEach(thumb => {
            thumb.setAttribute("aria-pressed", String(thumb === button));
        });
    });
});

document.addEventListener("submit", event => {
    const confirmation = event.submitter?.dataset.confirm;
    if (confirmation && !window.confirm(confirmation)) {
        event.preventDefault();
    }
});

const booking = document.getElementById("booking-form");
if (booking) {
    const update = () => {
        const { StartDate, StartTime, EndDate, EndTime, PaymentMethod } = booking.elements;
        const arrival = `${StartDate.value}T${StartTime.value}`;
        const departure = `${EndDate.value}T${EndTime.value}`;
        const output = document.getElementById("booking-total");
        output.textContent = "";
        if (StartDate.value && StartTime.value && EndDate.value && EndTime.value && departure > arrival) {
            const days = Math.max(1, (Date.parse(EndDate.value) - Date.parse(StartDate.value)) / 86400000);
            const total = (days * Number(booking.dataset.rate)).toLocaleString("vi-VN");
            output.textContent = `${days} đêm · Dự kiến ${total} ₫`;
        }
        const qr = document.getElementById("booking-qr");
        if (qr) {
            qr.hidden = PaymentMethod.value !== "online";
        }
    };
    booking.addEventListener("input", update);
    update();
}
