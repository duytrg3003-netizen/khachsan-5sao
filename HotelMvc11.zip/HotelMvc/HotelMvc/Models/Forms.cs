using System.ComponentModel.DataAnnotations;

namespace HotelMvc.Models;

public sealed class LoginForm
{
    [Required, StringLength(50), Display(Name = "Tên đăng nhập")]
    public string UserName { get; set; } = "";

    [Required, StringLength(128), DataType(DataType.Password), Display(Name = "Mật khẩu")]
    public string Password { get; set; } = "";

    public string? ReturnUrl { get; set; }
}

public sealed class RegisterForm
{
    [Required, StringLength(100), Display(Name = "Họ và tên")]
    public string FullName { get; set; } = "";

    [Required, RegularExpression(@"[0-9+ .()-]{8,15}"), Display(Name = "Số điện thoại")]
    public string Phone { get; set; } = "";

    [Required, StringLength(50, MinimumLength = 3), RegularExpression(@"[a-zA-Z0-9_.-]+"), Display(Name = "Tên đăng nhập")]
    public string UserName { get; set; } = "";

    [Required, StringLength(128, MinimumLength = 8), DataType(DataType.Password), Display(Name = "Mật khẩu")]
    public string Password { get; set; } = "";
}

public sealed class BookingForm
{
    public int RoomId { get; set; }

    [Required, Display(Name = "Ngày nhận phòng")]
    public DateOnly? StartDate { get; set; }

    [Required, Display(Name = "Giờ nhận phòng")]
    public TimeOnly? StartTime { get; set; }

    [Required, Display(Name = "Ngày trả phòng")]
    public DateOnly? EndDate { get; set; }

    [Required, Display(Name = "Giờ trả phòng")]
    public TimeOnly? EndTime { get; set; }

    [Range(1, 20), Display(Name = "Số khách")]
    public int People { get; set; } = 1;

    [Required, RegularExpression("cash|online"), Display(Name = "Thanh toán")]
    public string PaymentMethod { get; set; } = HotelRules.Cash;

    public Room? Room { get; set; }
    public string? PaymentQr { get; set; }
}

public sealed class RoomForm
{
    public int Id { get; set; }

    [Required, StringLength(10), Display(Name = "Số phòng")]
    public string Number { get; set; } = "";

    [Range(1, int.MaxValue), Display(Name = "Loại phòng")]
    public int TypeId { get; set; }

    [StringLength(255), Display(Name = "Mô tả")]
    public string? Description { get; set; }

    [Display(Name = "Thêm ảnh phòng")]
    public List<IFormFile> Photos { get; set; } = [];

    public IReadOnlyList<RoomType> Types { get; set; } = [];
    public IReadOnlyList<string> ExistingPhotos { get; set; } = [];
}

public sealed class StaffForm
{
    [Required, StringLength(100), Display(Name = "Họ và tên")]
    public string FullName { get; set; } = "";

    [Required, StringLength(100), Display(Name = "Chức vụ")]
    public string Position { get; set; } = "";

    [RegularExpression(@"[0-9+ .()-]{8,15}"), Display(Name = "Số điện thoại")]
    public string? Phone { get; set; }

    [Range(typeof(decimal), "0", "999999999999999"), Display(Name = "Lương tháng (₫)")]
    public decimal Salary { get; set; }
}

public sealed record StaffPage(StaffForm Form, IReadOnlyList<Employee> Employees);
public sealed record OrdersPage(IReadOnlyList<Booking> Bookings, int CustomerCount, string? PaymentQr);
public sealed record ScheduleRoom(Room Room, IReadOnlyList<Booking> Bookings);
public sealed record BookingTable(IReadOnlyList<Booking> Bookings, bool Admin = false);
