using System.Text.Json;

namespace HotelMvc.Models;

public static class Photos
{
    public const int MaxCount = 6;
    public const int MaxBytes = 1024 * 1024;
    public const string Accepted = "image/jpeg,image/png,image/webp";

    public static IReadOnlyList<string> Read(string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw))
            return [];
        if (!raw.StartsWith('['))
            return IsImageUrl(raw) ? [raw] : [];
        try
        {
            return (JsonSerializer.Deserialize<string[]>(raw) ?? [])
                .Where(IsImageUrl).ToArray();
        }
        catch (JsonException)
        {
            return [];
        }
    }

    private static bool IsImageUrl(string? value) => value is not null &&
        (value.StartsWith("data:image/jpeg;base64,", StringComparison.Ordinal) ||
         value.StartsWith("data:image/png;base64,", StringComparison.Ordinal) ||
         value.StartsWith("data:image/webp;base64,", StringComparison.Ordinal) ||
         (Uri.TryCreate(value, UriKind.Absolute, out var uri) && uri.Scheme == "https"));

    public static async Task<string?> EncodeAsync(IFormFile file, CancellationToken cancellationToken)
    {
        if (file.Length is <= 0 or > MaxBytes)
            return null;
        using var buffer = new MemoryStream();
        await file.CopyToAsync(buffer, cancellationToken);
        var bytes = buffer.ToArray();
        var mime = ImageType(bytes);
        return mime is null ? null : $"data:{mime};base64,{Convert.ToBase64String(bytes)}";
    }

    private static string? ImageType(ReadOnlySpan<byte> bytes)
    {
        if (bytes.StartsWith(new byte[] { 0xFF, 0xD8, 0xFF }))
            return "image/jpeg";
        if (bytes.StartsWith(new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 }))
            return "image/png";
        if (bytes.Length >= 12 && bytes.StartsWith("RIFF"u8) && bytes[8..].StartsWith("WEBP"u8))
            return "image/webp";
        return null;
    }
}
