namespace HotelMvc.Models;

public sealed class Account
{
    public int Id { get; set; }
    public string UserName { get; set; } = "";
    public string Password { get; set; } = "";
    public string Role { get; set; } = "";
}

public sealed class Customer
{
    public int Id { get; set; }
    public string FullName { get; set; } = "";
    public string? Phone { get; set; }
    public int? AccountId { get; set; }
}

public sealed class RoomType
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public decimal Rate { get; set; }
}

public sealed class Room
{
    public int Id { get; set; }
    public string Number { get; set; } = "";
    public string? Description { get; set; }
    public string? Photo { get; set; }
    public string? Status { get; set; }
    public int? TypeId { get; set; }
    public RoomType? Type { get; set; }
}

public sealed class Booking
{
    public int Id { get; set; }
    public int People { get; set; }
    public DateTime Start { get; set; }
    public DateTime End { get; set; }
    public decimal? Deposit { get; set; }
    public string? PaymentStatus { get; set; }
    public int? CustomerId { get; set; }
    public Customer? Customer { get; set; }
    public int? RoomId { get; set; }
    public Room? Room { get; set; }
    public string Status { get; set; } = HotelRules.Waiting;
    public string PaymentMethod { get; set; } = HotelRules.Cash;
    public decimal? QuotedTotal { get; set; }
    public DateTime? ActualIn { get; set; }
    public DateTime? ActualOut { get; set; }
    public List<Invoice> Invoices { get; set; } = [];

    public decimal Total => Invoices.OrderByDescending(x => x.Id).FirstOrDefault()?.Total
        ?? QuotedTotal ?? HotelRules.Nights(Start, End) * (Room?.Type?.Rate ?? 0);
}

public sealed class Invoice
{
    public int Id { get; set; }
    public DateTime? CreatedAt { get; set; }
    public decimal Total { get; set; }
    public int? BookingId { get; set; }
}

public sealed class HotelService
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public decimal Rate { get; set; }
}

public sealed class Employee
{
    public int Id { get; set; }
    public string FullName { get; set; } = "";
    public string Position { get; set; } = "";
    public string? Phone { get; set; }
    public decimal Salary { get; set; }
}

public sealed class HotelSettings
{
    public int Id { get; set; }
    public string? PaymentQr { get; set; }
}

public static class HotelRules
{
    public const string Admin = "Admin";
    public const string Guest = "KhachHang";
    public const string Waiting = "Chờ nhận phòng";
    public const string Staying = "Đang ở";
    public const string CheckedOut = "Đã trả phòng";
    public const string Cancelled = "Đã hủy";
    public const string Unpaid = "Chưa trả";
    public const string Paid = "Đã trả";
    public const string Cash = "cash";
    public const string Transfer = "online";
    public const string Available = "Trống";
    public const string Occupied = "Đang sử dụng";

    public static DateTime Now => DateTime.UtcNow.AddHours(7);
    public static int Nights(DateTime start, DateTime end) => Math.Max(1, (end.Date - start.Date).Days);
    public static string Money(decimal value) => value.ToString("N0", System.Globalization.CultureInfo.GetCultureInfo("vi-VN")) + " ₫";
}
