﻿using System.ComponentModel.DataAnnotations;

namespace HotelMvc.Models;

public class NewPasswordForm
{
    [Required(ErrorMessage = "Nhập mật khẩu mới.")]
    [StringLength(128, ErrorMessage = "Mật khẩu mới tối đa 128 ký tự.")]
    [DataType(DataType.Password)]
    [Display(Name = "Mật khẩu mới")]
    public string Password { get; set; } = "";

    [Required(ErrorMessage = "Nhập lại mật khẩu mới.")]
    [Compare(nameof(Password), ErrorMessage = "Hai mật khẩu mới chưa khớp.")]
    [DataType(DataType.Password)]
    [Display(Name = "Nhập lại mật khẩu mới")]
    public string ConfirmPassword { get; set; } = "";
}

public sealed class ChangePasswordForm : NewPasswordForm
{
    [Required(ErrorMessage = "Nhập mật khẩu hiện tại.")]
    [StringLength(128)]
    [DataType(DataType.Password)]
    [Display(Name = "Mật khẩu hiện tại")]
    public string CurrentPassword { get; set; } = "";
}

public sealed class CustomerAccountSummary
{
    public int CustomerId { get; init; }
    public int AccountId { get; init; }
    public string UserName { get; init; } = "";
    public string FullName { get; init; } = "";
    public string? Phone { get; init; }
}

public sealed record CustomerAccountSearch(
    string? Phone,
    IReadOnlyList<CustomerAccountSummary> Customers);