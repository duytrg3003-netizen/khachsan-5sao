using HotelMvc.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelMvc.Data;

public sealed class HotelDb(DbContextOptions<HotelDb> options) : DbContext(options)
{
    public DbSet<Account> Accounts => Set<Account>();
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<RoomType> RoomTypes => Set<RoomType>();
    public DbSet<Room> Rooms => Set<Room>();
    public DbSet<Booking> Bookings => Set<Booking>();
    public DbSet<Invoice> Invoices => Set<Invoice>();
    public DbSet<HotelService> Services => Set<HotelService>();
    public DbSet<Employee> Employees => Set<Employee>();
    public DbSet<HotelSettings> Settings => Set<HotelSettings>();

    public IQueryable<Booking> BookingDetails => Bookings
        .Include(x => x.Room).ThenInclude(x => x!.Type)
        .Include(x => x.Customer)
        .Include(x => x.Invoices);

    protected override void OnModelCreating(ModelBuilder model)
    {
        model.HasDefaultSchema("dbo");
        var accounts = model.Entity<Account>().ToTable("tai_khoan");
        accounts.Property(x => x.Id).HasColumnName("id");
        accounts.Property(x => x.UserName).HasColumnName("ten_dang_nhap").HasMaxLength(50);
        accounts.Property(x => x.Password).HasColumnName("mat_khau").HasMaxLength(255);
        accounts.Property(x => x.Role).HasColumnName("vai_tro").HasMaxLength(20);

        var customers = model.Entity<Customer>().ToTable("khach_hang");
        customers.Property(x => x.Id).HasColumnName("ma_kh");
        customers.Property(x => x.FullName).HasColumnName("ho_ten").HasMaxLength(100);
        customers.Property(x => x.Phone).HasColumnName("so_dt").HasMaxLength(15);
        customers.Property(x => x.AccountId).HasColumnName("tai_khoan_id");
        customers.HasOne<Account>().WithMany().HasForeignKey(x => x.AccountId).OnDelete(DeleteBehavior.NoAction);

        var types = model.Entity<RoomType>().ToTable("loai_phong");
        types.Property(x => x.Id).HasColumnName("ma_lp");
        types.Property(x => x.Name).HasColumnName("ten_lp").HasMaxLength(50);
        types.Property(x => x.Rate).HasColumnName("don_gia").HasPrecision(15, 0);

        var rooms = model.Entity<Room>().ToTable("phong");
        rooms.Property(x => x.Id).HasColumnName("ma_p");
        rooms.Property(x => x.Number).HasColumnName("so_phong").HasMaxLength(10);
        rooms.Property(x => x.Description).HasColumnName("mo_ta").HasMaxLength(255);
        rooms.Property(x => x.Photo).HasColumnName("hinh_anh");
        rooms.Property(x => x.Status).HasColumnName("trang_thai").HasMaxLength(30);
        rooms.Property(x => x.TypeId).HasColumnName("ma_lp");
        rooms.HasOne(x => x.Type).WithMany().HasForeignKey(x => x.TypeId).OnDelete(DeleteBehavior.NoAction);

        var bookings = model.Entity<Booking>().ToTable("dat_phong");
        bookings.Property(x => x.Id).HasColumnName("ma_dp");
        bookings.Property(x => x.People).HasColumnName("so_nguoi");
        bookings.Property(x => x.Start).HasColumnName("ngay_bat_dau").HasPrecision(0);
        bookings.Property(x => x.End).HasColumnName("ngay_ket_thuc").HasPrecision(0);
        bookings.Property(x => x.Deposit).HasColumnName("tien_dat_coc").HasPrecision(15, 0);
        bookings.Property(x => x.PaymentStatus).HasColumnName("trang_thai_tt").HasMaxLength(30);
        bookings.Property(x => x.CustomerId).HasColumnName("ma_kh");
        bookings.Property(x => x.RoomId).HasColumnName("ma_p");
        bookings.Property(x => x.Status).HasColumnName("trang_thai_dp").HasMaxLength(30);
        bookings.Property(x => x.PaymentMethod).HasColumnName("hinh_thuc_tt").HasMaxLength(10);
        bookings.Property(x => x.QuotedTotal).HasColumnName("tong_tien_du_kien").HasPrecision(15, 0);
        bookings.Property(x => x.ActualIn).HasColumnName("gio_vao_thuc_te").HasPrecision(0);
        bookings.Property(x => x.ActualOut).HasColumnName("gio_ra_thuc_te").HasPrecision(0);
        bookings.HasOne(x => x.Room).WithMany().HasForeignKey(x => x.RoomId).OnDelete(DeleteBehavior.NoAction);
        bookings.HasOne(x => x.Customer).WithMany().HasForeignKey(x => x.CustomerId).OnDelete(DeleteBehavior.NoAction);

        var invoices = model.Entity<Invoice>().ToTable("hoa_don");
        invoices.Property(x => x.Id).HasColumnName("ma_hd");
        invoices.Property(x => x.CreatedAt).HasColumnName("ngay_lap").HasPrecision(0);
        invoices.Property(x => x.Total).HasColumnName("tong_tien").HasPrecision(15, 0);
        invoices.Property(x => x.BookingId).HasColumnName("ma_dp");
        invoices.HasOne<Booking>().WithMany(x => x.Invoices).HasForeignKey(x => x.BookingId).OnDelete(DeleteBehavior.NoAction);

        var services = model.Entity<HotelService>().ToTable("dich_vu");
        services.Property(x => x.Id).HasColumnName("ma_dv");
        services.Property(x => x.Name).HasColumnName("ten_dv").HasMaxLength(100);
        services.Property(x => x.Rate).HasColumnName("don_gia").HasPrecision(15, 0);

        var employees = model.Entity<Employee>().ToTable("nhan_vien");
        employees.Property(x => x.Id).HasColumnName("ma_nv");
        employees.Property(x => x.FullName).HasColumnName("ho_ten").HasMaxLength(100);
        employees.Property(x => x.Position).HasColumnName("chuc_vu").HasMaxLength(100);
        employees.Property(x => x.Phone).HasColumnName("so_dt").HasMaxLength(15);
        employees.Property(x => x.Salary).HasColumnName("luong").HasPrecision(15, 0);

        var settings = model.Entity<HotelSettings>().ToTable("cau_hinh_khach_san");
        settings.Property(x => x.Id).HasColumnName("id").ValueGeneratedNever();
        settings.Property(x => x.PaymentQr).HasColumnName("anh_qr");
    }
}
