using Microsoft.EntityFrameworkCore;

namespace HotelMvc.Data;

public static class RoomLock
{
    // Mọi thao tác ghi của cùng một phòng dùng khóa đến khi transaction kết thúc.
    public static Task AcquireAsync(HotelDb db, int roomId, CancellationToken token)
    {
        var resource = $"HotelMvc:Room:{roomId}";
        return db.Database.ExecuteSqlInterpolatedAsync($"""
            DECLARE @result int;
            EXEC @result = sys.sp_getapplock
                @Resource = {resource}, @LockMode = 'Exclusive',
                @LockOwner = 'Transaction', @LockTimeout = 5000;
            IF @result < 0 THROW 51001, 'Room lock unavailable.', 1;
            """, token);
    }
}
