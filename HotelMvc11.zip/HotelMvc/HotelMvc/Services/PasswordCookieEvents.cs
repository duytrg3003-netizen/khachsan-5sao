﻿using System.Security.Claims;
using HotelMvc.Data;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;

namespace HotelMvc.Services;

public sealed class PasswordCookieEvents(HotelDb db) : CookieAuthenticationEvents
{
    public override async Task ValidatePrincipal(CookieValidatePrincipalContext context)
    {
        var principal = context.Principal;

        if (principal is not null &&
            int.TryParse(principal.FindFirstValue(ClaimTypes.NameIdentifier), out var accountId) &&
            principal.FindFirstValue(AccountPasswords.VersionClaim) is { } version)
        {
            var account = await db.Accounts.AsNoTracking()
                .Where(x => x.Id == accountId)
                .Select(x => new { x.Password, x.Role })
                .SingleOrDefaultAsync(context.HttpContext.RequestAborted);

            if (account is not null &&
                principal.IsInRole(account.Role) &&
                AccountPasswords.Version(account.Password) == version)
                return;
        }

        context.RejectPrincipal();
        await context.HttpContext.SignOutAsync(context.Scheme.Name);
    }
}