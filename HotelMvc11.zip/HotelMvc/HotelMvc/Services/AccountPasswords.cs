﻿using System.Security.Cryptography;
using System.Text;
using HotelMvc.Data;
using HotelMvc.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace HotelMvc.Services;

public sealed class AccountPasswords(HotelDb db, IPasswordHasher<Account> hasher)
{
    public const string VersionClaim = "hotel:password-version";

    public PasswordVerificationResult Verify(Account account, string password)
    {
        try
        {
            var result = hasher.VerifyHashedPassword(account, account.Password, password);
            if (result != PasswordVerificationResult.Failed)
                return result;
        }
        catch (FormatException)
        {
            // Dữ liệu mẫu ban đầu có thể chưa được băm.
        }

        if ((account.Id, account.UserName, account.Role) is
            ((1, "abc", HotelRules.Admin) or (2, "khach1", HotelRules.Guest)) &&
            account.Password == "1234" &&
            CryptographicOperations.FixedTimeEquals(
                Encoding.UTF8.GetBytes(account.Password),
                Encoding.UTF8.GetBytes(password)))
        {
            return PasswordVerificationResult.SuccessRehashNeeded;
        }

        return PasswordVerificationResult.Failed;
    }

    public async Task<bool> TryReplaceAsync(
        Account account, string password, CancellationToken token)
    {
        var current = account.Password;
        var replacement = hasher.HashPassword(account, password);

        var updated = await db.Accounts
            .Where(x => x.Id == account.Id && x.Role == account.Role && x.Password == current)
            .ExecuteUpdateAsync(setters => setters.SetProperty(x => x.Password, replacement), token);

        if (updated != 1)
            return false;

        account.Password = replacement;
        return true;
    }

    public static string Version(string passwordHash) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(passwordHash)));
}