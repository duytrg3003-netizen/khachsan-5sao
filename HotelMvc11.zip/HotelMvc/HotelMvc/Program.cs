using HotelMvc.Data;
using HotelMvc.Models;
using HotelMvc.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

var connection = builder.Configuration.GetConnectionString("HotelDb")
    ?? throw new InvalidOperationException(
        "Cấu hình ConnectionStrings:HotelDb trước khi chạy.");

builder.Services.AddDbContext<HotelDb>(options => options.UseSqlServer(connection));

builder.Services.AddScoped<IPasswordHasher<Account>, PasswordHasher<Account>>();
builder.Services.AddScoped<AccountPasswords>();
builder.Services.AddScoped<PasswordCookieEvents>();

builder.Services.AddControllersWithViews(options =>
    options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute()));

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/Denied";
        options.Cookie.Name = "HotelMvc.Auth";
        options.Cookie.HttpOnly = true;
        options.EventsType = typeof(PasswordCookieEvents);
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
    });

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Hotel/Error");
    app.UseHsts();
}

app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute("default", "{controller=Hotel}/{action=Index}/{id?}");

app.Run();