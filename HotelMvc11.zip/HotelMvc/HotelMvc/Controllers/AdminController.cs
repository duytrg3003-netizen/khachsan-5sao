using System.Text.Json;
using HotelMvc.Data;
using HotelMvc.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace HotelMvc.Controllers;

[Authorize(Roles = HotelRules.Admin)]
public sealed class AdminController(HotelDb db) : Controller
{
    public async Task<IActionResult> Rooms(CancellationToken token) =>
        View(await db.Rooms.AsNoTracking().Include(x => x.Type).OrderBy(x => x.Number).ToListAsync(token));

    [HttpGet]
    public async Task<IActionResult> EditRoom(int? id, CancellationToken token)
    {
        if (id is null)
            return View(await LoadRoomFormAsync(new RoomForm(), null, token));
        var room = await db.Rooms.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id, token);
        if (room is null)
            return NotFound();
        var form = new RoomForm { Id = room.Id, Number = room.Number, TypeId = room.TypeId ?? 0, Description = room.Description };
        return View(await LoadRoomFormAsync(form, room, token));
    }

    [HttpPost, RequestSizeLimit(7 * 1024 * 1024)]
    public async Task<IActionResult> EditRoom(RoomForm form, CancellationToken token)
    {
        await using var transaction = await db.Database.BeginTransactionAsync(token);
        Room? room = null;
        try
        {
            if (form.Id != 0)
            {
                await RoomLock.AcquireAsync(db, form.Id, token);
                room = await db.Rooms.FindAsync([form.Id], token);
                if (room is null)
                    return NotFound();
            }
            await LoadRoomFormAsync(form, room, token);
            if (!form.Types.Any(x => x.Id == form.TypeId))
                ModelState.AddModelError(nameof(form.TypeId), "Chọn loại phòng trong danh sách.");
            if (form.ExistingPhotos.Count + form.Photos.Count > Photos.MaxCount)
                ModelState.AddModelError(nameof(form.Photos), $"Mỗi phòng có tối đa {Photos.MaxCount} ảnh.");
            if (!ModelState.IsValid)
                return View(form);

            var images = form.ExistingPhotos.ToList();
            foreach (var file in form.Photos)
            {
                var image = await Photos.EncodeAsync(file, token);
                if (image is null)
                {
                    ModelState.AddModelError(nameof(form.Photos), "Chọn ảnh JPG, PNG hoặc WebP tối đa 1 MB mỗi ảnh.");
                    return View(form);
                }
                images.Add(image);
            }

            if (room is null)
            {
                room = new Room { Status = HotelRules.Available };
                db.Rooms.Add(room);
            }
            room.Number = form.Number.Trim();
            room.TypeId = form.TypeId;
            room.Description = form.Description?.Trim();
            if (form.Photos.Count > 0)
                room.Photo = JsonSerializer.Serialize(images);
            await db.SaveChangesAsync(token);
            await transaction.CommitAsync(token);
            TempData["Notice"] = "Đã lưu phòng.";
        }
        catch (DbUpdateException exception) when (exception.InnerException is SqlException { Number: 2601 or 2627 })
        {
            ModelState.AddModelError(nameof(form.Number), "Số phòng đã tồn tại.");
            return View(form);
        }
        catch (SqlException exception) when (exception.Number == 51001)
        {
            TempData["Notice"] = "Phòng đang được xử lý. Vui lòng thử lại.";
        }
        return RedirectToAction(nameof(Rooms));
    }

    [HttpPost]
    public async Task<IActionResult> DeletePhoto(int id, int index, CancellationToken token)
    {
        await using var transaction = await db.Database.BeginTransactionAsync(token);
        try
        {
            await RoomLock.AcquireAsync(db, id, token);
            var room = await db.Rooms.FindAsync([id], token);
            if (room is null)
                return NotFound();
            var photos = Photos.Read(room.Photo).ToList();
            if (index < 0 || index >= photos.Count)
                return BadRequest();
            photos.RemoveAt(index);
            room.Photo = photos.Count == 0 ? null : JsonSerializer.Serialize(photos);
            await db.SaveChangesAsync(token);
            await transaction.CommitAsync(token);
            TempData["Notice"] = "Đã xóa ảnh.";
        }
        catch (SqlException exception) when (exception.Number == 51001)
        {
            TempData["Notice"] = "Phòng đang được xử lý. Vui lòng thử lại.";
        }
        return RedirectToAction(nameof(EditRoom), new { id });
    }

    [HttpPost]
    public async Task<IActionResult> DeleteRoom(int id, CancellationToken token)
    {
        await using var transaction = await db.Database.BeginTransactionAsync(token);
        try
        {
            await RoomLock.AcquireAsync(db, id, token);
            if (await db.Bookings.AnyAsync(x => x.RoomId == id, token))
            {
                TempData["Notice"] = "Phòng có lịch sử đặt nên được giữ lại.";
                return RedirectToAction(nameof(Rooms));
            }

            var count = await db.Rooms.Where(x => x.Id == id).ExecuteDeleteAsync(token);
            await transaction.CommitAsync(token);
            TempData["Notice"] = count == 1 ? "Đã xóa phòng." : "Phòng đã được xóa.";
        }
        catch (SqlException exception) when (exception.Number is 51001 or 547)
        {
            TempData["Notice"] = "Phòng đang có dữ liệu liên quan hoặc đang được xử lý.";
        }
        return RedirectToAction(nameof(Rooms));
    }

    public async Task<IActionResult> Orders(CancellationToken token) =>
        View(new OrdersPage(
            await db.BookingDetails.AsNoTracking().OrderByDescending(x => x.Id).ToListAsync(token),
            await db.Customers.CountAsync(token),
            await db.Settings.Where(x => x.Id == 1).Select(x => x.PaymentQr).SingleAsync(token)));

    [HttpPost, RequestSizeLimit(2 * 1024 * 1024)]
    public async Task<IActionResult> SaveQr(IFormFile? qrImage, CancellationToken token)
    {
        var image = qrImage is null ? null : await Photos.EncodeAsync(qrImage, token);
        if (image is null)
            TempData["Notice"] = "Chọn một ảnh mã QR định dạng JPG, PNG hoặc WebP tối đa 1 MB.";
        else
        {
            await db.Settings.Where(x => x.Id == 1)
                .ExecuteUpdateAsync(update => update.SetProperty(x => x.PaymentQr, image), token);
            TempData["Notice"] = "Đã cập nhật mã QR.";
        }
        return RedirectToAction(nameof(Orders));
    }

    [HttpPost]
    public async Task<IActionResult> OrderAction(int id, string operation, CancellationToken token)
    {
        await using var transaction = await db.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable, token);
        try
        {
            var key = await db.Bookings.AsNoTracking().Where(x => x.Id == id)
                .Select(x => new { x.RoomId }).SingleOrDefaultAsync(token);
            if (key is null)
                return NotFound();
            if (key.RoomId is int roomId)
                await RoomLock.AcquireAsync(db, roomId, token);

            var booking = await db.BookingDetails.SingleAsync(x => x.Id == id, token);
            var result = await ApplyOrderActionAsync(booking, operation, token);
            await db.SaveChangesAsync(token);
            await transaction.CommitAsync(token);
            TempData["Notice"] = result;
        }
        catch (SqlException exception) when (exception.Number is 51001 or 1205)
        {
            TempData["Notice"] = "Đơn đang được xử lý. Vui lòng thử lại.";
        }
        catch (DbUpdateException exception) when (exception.InnerException is SqlException { Number: 1205 })
        {
            TempData["Notice"] = "Đơn đang được xử lý. Vui lòng thử lại.";
        }
        return RedirectToAction(nameof(Orders));
    }

    public async Task<IActionResult> Schedule(CancellationToken token)
    {
        var rooms = await db.Rooms.AsNoTracking().Include(x => x.Type).OrderBy(x => x.Number).ToListAsync(token);
        var bookings = await db.BookingDetails.AsNoTracking().Where(x => x.Status != HotelRules.Cancelled)
            .OrderBy(x => x.Start).ToListAsync(token);
        var byRoom = bookings.ToLookup(x => x.RoomId);
        return View(rooms.Select(x => new ScheduleRoom(x, byRoom[x.Id].ToList())).ToList());
    }

    public async Task<IActionResult> Staff(CancellationToken token) => View(await StaffPageAsync(new StaffForm(), token));

    [HttpPost]
    public async Task<IActionResult> AddStaff([Bind(Prefix = "Form")] StaffForm form, CancellationToken token)
    {
        if (form.Salary != decimal.Truncate(form.Salary))
            ModelState.AddModelError("Form.Salary", "Nhập số tiền bằng đồng, không có phần thập phân.");
        if (!ModelState.IsValid)
            return View("Staff", await StaffPageAsync(form, token));

        db.Employees.Add(new Employee
        {
            FullName = form.FullName.Trim(),
            Position = form.Position.Trim(),
            Phone = form.Phone?.Trim(),
            Salary = form.Salary
        });
        await db.SaveChangesAsync(token);
        TempData["Notice"] = "Đã thêm nhân viên.";
        return RedirectToAction(nameof(Staff));
    }

    [HttpPost]
    public async Task<IActionResult> DeleteStaff(int id, CancellationToken token)
    {
        await db.Employees.Where(x => x.Id == id).ExecuteDeleteAsync(token);
        TempData["Notice"] = "Đã xóa nhân viên.";
        return RedirectToAction(nameof(Staff));
    }

    public IActionResult Cameras() => View();

    private async Task<string> ApplyOrderActionAsync(Booking booking, string operation, CancellationToken token)
    {
        switch (operation)
        {
            case "collect" when booking.PaymentStatus != HotelRules.Paid && booking.Status != HotelRules.Cancelled:
                if (booking.Invoices.Count == 0)
                    booking.Invoices.Add(new Invoice { Total = booking.Total, CreatedAt = HotelRules.Now });
                booking.PaymentStatus = HotelRules.Paid;
                return "Đã ghi nhận thanh toán.";

            case "checkin" when booking.Status == HotelRules.Waiting && booking.Room is { } room:
                if (booking.End <= HotelRules.Now)
                    return "Lịch của đơn đã kết thúc.";
                if (await db.Bookings.AnyAsync(x => x.RoomId == room.Id && x.Id != booking.Id &&
                        x.Status == HotelRules.Staying, token))
                    return "Phòng đang có khách.";
                booking.Status = HotelRules.Staying;
                booking.ActualIn = HotelRules.Now;
                room.Status = HotelRules.Occupied;
                return "Đã nhận phòng.";

            case "checkout" when booking.Status == HotelRules.Staying:
                booking.Status = HotelRules.CheckedOut;
                booking.ActualOut = HotelRules.Now;
                if (booking.Room is { } checkedOutRoom)
                    checkedOutRoom.Status = HotelRules.Available;
                return "Đã trả phòng.";

            case "cancel" when booking.Status == HotelRules.Waiting && booking.PaymentStatus != HotelRules.Paid:
                booking.Status = HotelRules.Cancelled;
                return "Đã hủy đơn.";

            default:
                return "Thao tác không phù hợp với trạng thái đơn hiện tại.";
        }
    }

    private async Task<RoomForm> LoadRoomFormAsync(RoomForm form, Room? room, CancellationToken token)
    {
        form.ExistingPhotos = Photos.Read(room?.Photo);
        form.Types = await db.RoomTypes.AsNoTracking().OrderBy(x => x.Name).ToListAsync(token);
        return form;
    }

    private async Task<StaffPage> StaffPageAsync(StaffForm form, CancellationToken token) =>
        new(form, await db.Employees.AsNoTracking().OrderBy(x => x.FullName).ToListAsync(token));
}
