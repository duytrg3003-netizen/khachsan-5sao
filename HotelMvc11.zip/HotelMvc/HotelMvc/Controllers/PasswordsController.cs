﻿using System.Security.Claims;
using HotelMvc.Data;
using HotelMvc.Models;
using HotelMvc.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelMvc.Controllers;

[Authorize]
[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
public sealed class PasswordsController(
    HotelDb db,
    AccountPasswords passwords,
    ILogger<PasswordsController> logger) : Controller
{
    private int AccountId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [HttpGet]
    public IActionResult Change() => View(new ChangePasswordForm());

    [HttpPost]
    public async Task<IActionResult> Change(ChangePasswordForm form, CancellationToken token)
    {
        if (!ModelState.IsValid)
            return View(form);

        var account = await db.Accounts.AsNoTracking()
            .SingleOrDefaultAsync(x => x.Id == AccountId, token);

        if (account is null ||
            passwords.Verify(account, form.CurrentPassword) == PasswordVerificationResult.Failed)
        {
            ModelState.AddModelError(nameof(form.CurrentPassword), "Mật khẩu hiện tại chưa đúng.");
            return View(form);
        }

        if (form.Password == form.CurrentPassword)
        {
            ModelState.AddModelError(nameof(form.Password), "Hãy chọn mật khẩu khác mật khẩu hiện tại.");
            return View(form);
        }

        if (!await passwords.TryReplaceAsync(account, form.Password, token))
        {
            ModelState.AddModelError("", "Mật khẩu vừa được cập nhật. Vui lòng đăng nhập lại.");
            return View(form);
        }

        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        TempData["Notice"] = "Đã đổi mật khẩu. Hãy đăng nhập lại bằng mật khẩu mới.";
        return RedirectToAction("Login", "Account");
    }

    [Authorize(Roles = HotelRules.Admin), AcceptVerbs("GET", "POST")]
    public async Task<IActionResult> Customers([FromForm] string? phone, CancellationToken token)
    {
        

        if (string.IsNullOrWhiteSpace(phone))
            return View(new CustomerAccountSearch(null, []));

        phone = phone.Trim();
        var search = new string(phone.Where(c => c is not (' ' or '.' or '-' or '(' or ')')).ToArray());
        var digits = search.TrimStart('+');

        if (search.Length > 16 || digits.Length < 5 ||
            digits.Any(c => c is < '0' or > '9') || search.Length - digits.Length > 1)
        {
            ModelState.AddModelError("", "Nhập số điện thoại khách đã đăng ký.");
            return View(new CustomerAccountSearch(phone, []));
        }

        var alternate = search.StartsWith("+84", StringComparison.Ordinal)
            ? "0" + search[3..]
            : search.StartsWith('0') ? "+84" + search[1..] : search;

        var customers = await CustomerAccounts()
            .Where(x => x.Phone != null)
            .Select(x => new
            {
                Customer = x,
                Normalized = x.Phone!.Replace(" ", "").Replace(".", "")
                    .Replace("-", "").Replace("(", "").Replace(")", "")
            })
            .Where(x => x.Normalized == search || x.Normalized == alternate)
            .OrderBy(x => x.Customer.UserName)
            .ThenBy(x => x.Customer.CustomerId)
            .Select(x => x.Customer)
            .ToListAsync(token);

        return View(new CustomerAccountSearch(phone, customers));
    }

    [Authorize(Roles = HotelRules.Admin), HttpGet]
    public async Task<IActionResult> Reset(int id, CancellationToken token)
    {
        

        var customer = await CustomerAccounts()
            .SingleOrDefaultAsync(x => x.CustomerId == id, token);
        if (customer is null)
            return NotFound();

        ViewData["Customer"] = customer;
        return View(new NewPasswordForm());
    }

    [Authorize(Roles = HotelRules.Admin), HttpPost]
    public async Task<IActionResult> Reset(int id, NewPasswordForm form, CancellationToken token)
    {
        

        var customer = await CustomerAccounts()
            .SingleOrDefaultAsync(x => x.CustomerId == id, token);
        if (customer is null)
            return NotFound();

        ViewData["Customer"] = customer;
        if (!ModelState.IsValid)
            return View(form);

        var account = await db.Accounts.AsNoTracking()
            .SingleOrDefaultAsync(x => x.Id == customer.AccountId && x.Role == HotelRules.Guest, token);
        if (account is null)
            return NotFound();

        if (passwords.Verify(account, form.Password) != PasswordVerificationResult.Failed)
        {
            ModelState.AddModelError(nameof(form.Password), "Hãy chọn mật khẩu khác mật khẩu hiện tại của khách.");
            return View(form);
        }

        if (!await passwords.TryReplaceAsync(account, form.Password, token))
        {
            ModelState.AddModelError("", "Tài khoản vừa được cập nhật. Hãy tải lại trang và thử lại.");
            return View(form);
        }

        logger.LogInformation("Hotel administrator {AdminId} reset guest account {GuestId}.",
            AccountId, account.Id);

        TempData["Notice"] = $"Đã đặt lại mật khẩu cho {customer.UserName}. Hãy trao mật khẩu mới trực tiếp cho đúng khách.";
        return RedirectToAction(nameof(Customers));
    }

    private IQueryable<CustomerAccountSummary> CustomerAccounts() =>
        from customer in db.Customers.AsNoTracking()
        join account in db.Accounts.AsNoTracking() on customer.AccountId equals account.Id
        where account.Role == HotelRules.Guest
        select new CustomerAccountSummary
        {
            CustomerId = customer.Id,
            AccountId = account.Id,
            UserName = account.UserName,
            FullName = customer.FullName,
            Phone = customer.Phone
        };

    private async Task<bool> UsesDefaultAdminPasswordAsync(CancellationToken token)
    {
        if (AccountId != 1)
            return false;

        var account = await db.Accounts.AsNoTracking()
            .SingleOrDefaultAsync(x => x.Id == AccountId, token);

        return account is { UserName: "abc" } &&
            passwords.Verify(account, "1234") != PasswordVerificationResult.Failed;
    }

    private RedirectToActionResult RequireAdminPasswordChange()
    {
        TempData["Notice"] = "Hãy đổi mật khẩu mẫu của quản trị viên trước khi đặt lại mật khẩu cho khách.";
        return RedirectToAction(nameof(Change));
    }
}