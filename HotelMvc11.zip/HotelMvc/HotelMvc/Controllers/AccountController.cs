using HotelMvc.Services;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using HotelMvc.Data;
using HotelMvc.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace HotelMvc.Controllers;

public sealed class AccountController(
    HotelDb db, IPasswordHasher<Account> hasher, AccountPasswords passwords) : Controller
{
    [HttpGet]
    public IActionResult Login(string? returnUrl) => View(new LoginForm { ReturnUrl = returnUrl });

    [HttpPost]
    public async Task<IActionResult> Login(LoginForm form, CancellationToken token)
    {
        if (!ModelState.IsValid)
            return View(form);

        var account = await db.Accounts.SingleOrDefaultAsync(x => x.UserName == form.UserName.Trim(), token);
        if (account is null || account.Role is not (HotelRules.Admin or HotelRules.Guest))
            return LoginFailed(form);

        var result = passwords.Verify(account, form.Password);
        if (result == PasswordVerificationResult.Failed)
            return LoginFailed(form);

        if (result == PasswordVerificationResult.SuccessRehashNeeded &&
            !await passwords.TryReplaceAsync(account, form.Password, token))
            return LoginFailed(form);

        await SignInAsync(account);
        if (Url.IsLocalUrl(form.ReturnUrl))
            return LocalRedirect(form.ReturnUrl!);
        return account.Role == HotelRules.Admin
            ? RedirectToAction("Orders", "Admin")
            : RedirectToAction("Rooms", "Hotel");
    }

    [HttpGet]
    public IActionResult Register() => View(new RegisterForm());

    [HttpPost]
    public async Task<IActionResult> Register(RegisterForm form, CancellationToken token)
    {
        if (!ModelState.IsValid)
            return View(form);

        var account = new Account { UserName = form.UserName.Trim(), Role = HotelRules.Guest };
        account.Password = hasher.HashPassword(account, form.Password);
        await using var transaction = await db.Database.BeginTransactionAsync(token);
        try
        {
            db.Accounts.Add(account);
            await db.SaveChangesAsync(token);
            db.Customers.Add(new Customer
            {
                AccountId = account.Id,
                FullName = form.FullName.Trim(),
                Phone = form.Phone.Trim()
            });
            await db.SaveChangesAsync(token);
            await transaction.CommitAsync(token);
        }
        catch (DbUpdateException exception) when (exception.InnerException is SqlException { Number: 2601 or 2627 })
        {
            ModelState.AddModelError(nameof(form.UserName), "Tên đăng nhập đã được sử dụng.");
            return View(form);
        }

        await SignInAsync(account);
        return RedirectToAction("Rooms", "Hotel");
    }

    [Authorize, HttpPost]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction("Index", "Hotel");
    }

    public IActionResult Denied() => View();

    private IActionResult LoginFailed(LoginForm form)
    {
        ModelState.AddModelError("", "Tên đăng nhập hoặc mật khẩu không đúng.");
        return View("Login", form);
    }

    private PasswordVerificationResult VerifyPassword(Account account, string password)
    {
        try
        {
            var result = hasher.VerifyHashedPassword(account, account.Password, password);
            if (result != PasswordVerificationResult.Failed)
                return result;
        }
        catch (FormatException)
        {
            // Dữ liệu MySQL cũ có thể chứa mật khẩu dạng văn bản.
        }

        // Chỉ tương thích với hai tài khoản mẫu đã có trong bản SQL.
        if ((account.Id, account.UserName, account.Role) is
            ((1, "abc", HotelRules.Admin) or (2, "khach1", HotelRules.Guest)) &&
            account.Password == "1234" &&
            CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(account.Password), Encoding.UTF8.GetBytes(password)))
            return PasswordVerificationResult.SuccessRehashNeeded;
        return PasswordVerificationResult.Failed;
    }

    private Task SignInAsync(Account account)
    {
        var scheme = CookieAuthenticationDefaults.AuthenticationScheme;
        Claim[] claims =
        [
            new(ClaimTypes.NameIdentifier, account.Id.ToString()),
            new(ClaimTypes.Name, account.UserName),
            new(ClaimTypes.Role, account.Role),
new(AccountPasswords.VersionClaim, AccountPasswords.Version(account.Password))
        ];
        return HttpContext.SignInAsync(scheme, new ClaimsPrincipal(new ClaimsIdentity(claims, scheme)));
    }
}
