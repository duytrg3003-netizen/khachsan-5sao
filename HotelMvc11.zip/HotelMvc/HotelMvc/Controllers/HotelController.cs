using HotelMvc.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelMvc.Controllers;

public sealed class HotelController(HotelDb db) : Controller
{
    public async Task<IActionResult> Index(CancellationToken token) =>
        View(await db.Services.AsNoTracking().OrderBy(x => x.Id).ToListAsync(token));

    public async Task<IActionResult> Rooms(CancellationToken token) =>
        View(await db.Rooms.AsNoTracking().Include(x => x.Type).OrderBy(x => x.Number).ToListAsync(token));

    public async Task<IActionResult> Details(int id, CancellationToken token)
    {
        var room = await db.Rooms.AsNoTracking().Include(x => x.Type).SingleOrDefaultAsync(x => x.Id == id, token);
        return room is null ? NotFound() : View(room);
    }

    [IgnoreAntiforgeryToken]
    public IActionResult Error() => View();
}
