using System.Security.Claims;
using HotelMvc.Data;
using HotelMvc.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace HotelMvc.Controllers;

[Authorize(Roles = HotelRules.Guest)]
public sealed class BookingsController(HotelDb db) : Controller
{
    private int AccountId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    public async Task<IActionResult> Mine(CancellationToken token) =>
        View(await db.BookingDetails.AsNoTracking().Where(x => x.Customer!.AccountId == AccountId)
            .OrderByDescending(x => x.Id).ToListAsync(token));

    [HttpGet]
    public async Task<IActionResult> Create(int id, CancellationToken token)
    {
        var today = DateOnly.FromDateTime(HotelRules.Now);
        var form = new BookingForm
        {
            RoomId = id,
            StartDate = today.AddDays(1),
            StartTime = new TimeOnly(14, 0),
            EndDate = today.AddDays(2),
            EndTime = new TimeOnly(12, 0)
        };
        return await LoadFormAsync(form, token) ? View(form) : NotFound();
    }

    [HttpPost]
    public async Task<IActionResult> Create(BookingForm form, CancellationToken token)
    {
        if (!await LoadFormAsync(form, token))
            return NotFound();
        if (!ModelState.IsValid)
            return View(form);

        var start = form.StartDate!.Value.ToDateTime(form.StartTime!.Value);
        var end = form.EndDate!.Value.ToDateTime(form.EndTime!.Value);
        if (start < HotelRules.Now || end <= start)
            ModelState.AddModelError("", "Chọn giờ nhận phòng trong tương lai và giờ trả phòng sau giờ nhận.");
        if (form.PaymentMethod == HotelRules.Transfer && form.PaymentQr is null)
            ModelState.AddModelError(nameof(form.PaymentMethod), "Khách sạn chưa có mã QR.");
        if (!ModelState.IsValid)
            return View(form);

        var customerId = await db.Customers.Where(x => x.AccountId == AccountId)
            .OrderBy(x => x.Id).Select(x => (int?)x.Id).FirstOrDefaultAsync(token);
        if (customerId is null)
        {
            ModelState.AddModelError("", "Tài khoản chưa có hồ sơ khách hàng.");
            return View(form);
        }

        await using var transaction = await db.Database.BeginTransactionAsync(token);
        try
        {
            await RoomLock.AcquireAsync(db, form.RoomId, token);
            if (!await LoadFormAsync(form, token))
                return NotFound();
            if (form.PaymentMethod == HotelRules.Transfer && form.PaymentQr is null)
            {
                ModelState.AddModelError(nameof(form.PaymentMethod), "Khách sạn chưa có mã QR.");
                return View(form);
            }
            if (await db.Bookings.AnyAsync(x => x.RoomId == form.RoomId &&
                    x.Status != HotelRules.Cancelled && x.Status != HotelRules.CheckedOut &&
                    x.Start < end && x.End > start, token))
            {
                ModelState.AddModelError("", "Phòng đã được đặt trong khoảng thời gian này.");
                return View(form);
            }

            var total = HotelRules.Nights(start, end) * form.Room!.Type!.Rate;
            if (total > 999999999999999m)
            {
                ModelState.AddModelError("", "Tổng tiền của kỳ lưu trú vượt giới hạn.");
                return View(form);
            }
            db.Bookings.Add(new Booking
            {
                RoomId = form.RoomId,
                CustomerId = customerId,
                People = form.People,
                Start = start,
                End = end,
                PaymentMethod = form.PaymentMethod,
                PaymentStatus = HotelRules.Unpaid,
                Deposit = 0,
                QuotedTotal = total
            });
            await db.SaveChangesAsync(token);
            await transaction.CommitAsync(token);
        }
        catch (SqlException exception) when (exception.Number == 51001)
        {
            ModelState.AddModelError("", "Phòng đang được xử lý. Vui lòng thử lại.");
            return View(form);
        }

        TempData["Notice"] = "Đã gửi yêu cầu đặt phòng.";
        return RedirectToAction(nameof(Mine));
    }

    [HttpPost]
    public async Task<IActionResult> Cancel(int id, CancellationToken token)
    {
        var own = db.Bookings.Where(x => x.Id == id && x.Customer!.AccountId == AccountId);
        var booking = await own.AsNoTracking().SingleOrDefaultAsync(token);
        if (booking is null)
            return NotFound();

        await using var transaction = await db.Database.BeginTransactionAsync(token);
        try
        {
            if (booking.RoomId is int roomId)
                await RoomLock.AcquireAsync(db, roomId, token);
            var count = await own.Where(x => x.Status == HotelRules.Waiting && x.PaymentStatus != HotelRules.Paid)
                .ExecuteUpdateAsync(updates => updates.SetProperty(x => x.Status, HotelRules.Cancelled), token);
            await transaction.CommitAsync(token);
            TempData["Notice"] = count == 1 ? "Đã hủy đơn." : "Chỉ có thể hủy đơn chờ nhận phòng chưa thanh toán.";
        }
        catch (SqlException exception) when (exception.Number == 51001)
        {
            TempData["Notice"] = "Đơn đang được xử lý. Vui lòng thử lại.";
        }
        return RedirectToAction(nameof(Mine));
    }

    private async Task<bool> LoadFormAsync(BookingForm form, CancellationToken token)
    {
        form.Room = await db.Rooms.AsNoTracking().Include(x => x.Type)
            .SingleOrDefaultAsync(x => x.Id == form.RoomId && x.TypeId != null, token);
        if (form.Room?.Type is null)
            return false;
        form.PaymentQr = await db.Settings.Where(x => x.Id == 1).Select(x => x.PaymentQr).SingleAsync(token);
        return true;
    }
}
