# Inperia Sky Gaden

Website quản lý khách sạn bằng ASP.NET Core MVC, Razor, Entity Framework Core và SQL Server. Giao diện dựa trên mẫu HTML đính kèm. Phòng, khách hàng, đơn đặt, hóa đơn, nhân viên và mã QR được lưu trên SQL Server.

## Chạy trên Windows

1. Cài .NET 8 SDK và SQL Server. Nếu dùng Visual Studio 2022, bật workload **ASP.NET and web development**.
2. Trong SSMS, kết nối vào SQL Server và ghi lại **Server name**. Nếu chưa có tám bảng gốc của `quan_ly_khach_san`, mở `Database/01_quan_ly_khach_san.sql` và nhấn **F5** để chạy cả file. Nếu đã nhập thành công bản cơ sở dữ liệu ở bước trước, bắt đầu từ file số 02.
3. Mở và chạy toàn bộ `Database/02_bo_sung_cho_web.sql`. Script bổ sung trường trạng thái, giờ nhận/trả thực tế và cấu hình QR. Trạng thái của đơn cũ được suy ra từ lịch và tình trạng phòng.
4. Sửa `ConnectionStrings:HotelDb` trong `appsettings.json` để dùng đúng tên máy chủ ở bước 2. Ví dụ cho Windows Authentication với SQL Server Express

   ```json
   "ConnectionStrings": {
     "HotelDb": "Server=.\\SQLEXPRESS;Database=quan_ly_khach_san;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"
   }
   ```

   Với SQL Server Authentication, lưu chuỗi kết nối trong User Secrets của dự án. Thay các giá trị mẫu bằng cấu hình của bạn.

   ```powershell
   dotnet user-secrets set "ConnectionStrings:HotelDb" "Server=TEN_MAY_CHU;Database=quan_ly_khach_san;User Id=TEN_DANG_NHAP;Password=MAT_KHAU;Encrypt=True;TrustServerCertificate=True"
   ```

5. Mở `HotelMvc.csproj` bằng Visual Studio và chạy profile **HotelMvc**, hoặc mở terminal tại thư mục dự án.

   ```powershell
   dotnet restore
   dotnet run --launch-profile HotelMvc
   ```

   Địa chỉ HTTP mặc định là **http://localhost:5168**. Profile cũng có HTTPS tại **https://localhost:7168**. Trên máy chưa có chứng chỉ phát triển, chạy `dotnet dev-certs https --trust` trước khi khởi động profile.

## Tài khoản mẫu của bản SQL

| Vai trò | Tên đăng nhập | Mật khẩu |
| --- | --- | --- |
| Quản trị | `abc` | `1234` |
| Khách | `khach1` | `1234` |

Hai tài khoản mẫu dùng để chạy thử cục bộ. Ở lần đăng nhập đầu, ứng dụng chuyển mật khẩu mẫu trong SQL sang dạng băm. Tài khoản mới dùng mật khẩu từ 8 ký tự. Dùng tài khoản khách để tạo đơn và tài khoản quản trị để duyệt đơn.

## Luồng nghiệp vụ

- Khách xem phòng và giá theo loại phòng, chọn ngày giờ và số khách, rồi theo dõi hoặc hủy đơn chờ nhận phòng chưa thanh toán.
- Quản trị thêm, sửa phòng và ảnh, xem lịch, thu tiền, nhận hoặc trả phòng và quản lý nhân viên. Các phòng có lịch sử đặt được giữ lại để bảo toàn khóa ngoại.
- Khi có mã QR, khách có thể chọn chuyển khoản. Quản trị xác nhận thủ công và ứng dụng ghi hóa đơn vào `hoa_don`.
- Trang camera giữ chế độ mô phỏng của mẫu HTML.
- Giờ khách sạn dùng múi giờ Việt Nam, UTC+7.

## Ảnh minh họa

- [Ảnh bìa](https://www.pexels.com/photo/32755076/)
- [Nhà hàng](https://www.pexels.com/photo/4873365/)
- [Phòng gym](https://www.pexels.com/photo/13863730/)
- [Hồ bơi](https://www.pexels.com/photo/14022373/)
- [Hà Nội](https://www.pexels.com/photo/21081068/)
- [Ảnh mặc định của phòng](https://www.pexels.com/photo/271624/)
