document.querySelectorAll("[data-room-photo]").forEach(button => {
    button.addEventListener("click", () => {
        document.getElementById("room-photo").src = button.dataset.roomPhoto;
        document.querySelectorAll("[data-room-photo]").forEach(thumb => {
            thumb.setAttribute("aria-pressed", String(thumb === button));
        });
    });
});

document.addEventListener("submit", event => {
    const confirmation = event.submitter?.dataset.confirm;
    if (confirmation && !window.confirm(confirmation)) {
        event.preventDefault();
    }
});

const recovery = document.getElementById("password-recovery");
if (recovery) {
    const phoneForm = document.getElementById("recovery-phone-form");
    const resetForm = document.getElementById("recovery-reset-form");
    const phone = document.getElementById("recovery-phone");
    const code = document.getElementById("recovery-code");
    const password = document.getElementById("recovery-password");
    const confirm = document.getElementById("recovery-confirm");
    const status = document.getElementById("recovery-status");
    const error = document.getElementById("recovery-error");
    const demoCode = "123456";

    const restart = () => {
        phoneForm.reset();
        resetForm.reset();
        phoneForm.hidden = false;
        resetForm.hidden = true;
        status.textContent = "";
        error.textContent = "";
    };

    phoneForm.addEventListener("submit", event => {
        event.preventDefault();
        phoneForm.hidden = true;
        resetForm.hidden = false;
        status.textContent = `Mã OTP minh họa: ${demoCode}`;
        code.focus();
    });

    resetForm.addEventListener("submit", event => {
        event.preventDefault();
        if (code.value !== demoCode) {
            error.textContent = "Mã OTP chưa đúng. Hãy thử lại.";
            code.focus();
            return;
        }
        if (password.value !== confirm.value) {
            error.textContent = "Hai mật khẩu minh họa chưa khớp.";
            confirm.focus();
            return;
        }
        restart();
        phoneForm.hidden = true;
        status.textContent = "Đã hoàn tất mô phỏng. Mật khẩu tài khoản vẫn giữ nguyên.";
        recovery.querySelector("summary").focus();
    });

    document.getElementById("recovery-restart").addEventListener("click", () => {
        restart();
        phone.focus();
    });
    recovery.addEventListener("toggle", () => {
        if (!recovery.open) {
            restart();
        }
    });
}

const booking = document.getElementById("booking-form");
if (booking) {
    const update = () => {
        const { StartDate, StartTime, EndDate, EndTime, PaymentMethod } = booking.elements;
        const arrival = `${StartDate.value}T${StartTime.value}`;
        const departure = `${EndDate.value}T${EndTime.value}`;
        const output = document.getElementById("booking-total");
        output.textContent = "";
        if (StartDate.value && StartTime.value && EndDate.value && EndTime.value && departure > arrival) {
            const days = Math.max(1, (Date.parse(EndDate.value) - Date.parse(StartDate.value)) / 86400000);
            const total = (days * Number(booking.dataset.rate)).toLocaleString("vi-VN");
            output.textContent = `${days} đêm · Dự kiến ${total} ₫`;
        }
        const qr = document.getElementById("booking-qr");
        if (qr) {
            qr.hidden = PaymentMethod.value !== "online";
        }
    };
    booking.addEventListener("input", update);
    update();
}
